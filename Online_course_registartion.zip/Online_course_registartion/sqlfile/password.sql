UPDATE `onlinecourse`.`admin`
SET
`id` = 1,
`username` = 'admin',
`password` = md5('<your Password>'),
`creationDate` = CURRENT_TIMESTAMP,
`updationDate` = CURRENT_TIMESTAMP
WHERE id=1;

SELECT * FROM onlinecourse.admin;

-- After first login changed to admin/admin