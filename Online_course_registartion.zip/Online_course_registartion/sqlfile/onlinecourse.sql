-- MySQL dump 10.13  Distrib 5.7.31, for Linux (x86_64)
--
-- Host: localhost    Database: onlinecourse
-- ------------------------------------------------------
-- Server version	5.7.31-0ubuntu0.18.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `creationDate` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

--LOCK TABLES `admin` WRITE;
--/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
--INSERT INTO `admin` VALUES (1,'admin','32250170a0dca92d53ec9624f336ca24','2017-01-24 16:21:18','21-05-2018 03:31:37 PM');
--/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
--UNLOCK TABLES;

--
-- Table structure for table `course`
--

DROP TABLE IF EXISTS `course`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `course` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `courseCode` varchar(255) DEFAULT NULL,
  `courseName` varchar(255) DEFAULT NULL,
  `courseUnit` varchar(255) DEFAULT NULL,
  `noofSeats` int(11) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `course`
--

LOCK TABLES `course` WRITE;
/*!40000 ALTER TABLE `course` DISABLE KEYS */;
INSERT INTO `course` VALUES (1,'PHP01','Core PHP','1-5',10,'2017-02-11 17:39:10','21-05-2018 03:33:37 PM'),(2,'WP01','Wordpress','1-6',1,'2017-02-11 17:52:25','12-02-2017 12:23:35 AM'),(4,'MYSQL23','MYSQL','1-8',20,'2017-02-11 18:47:25','25-08-2018 11:20:22 AM'),(5,'MACT','Modern Accounts','Unit 3',50,'2020-07-30 15:09:08',NULL);
/*!40000 ALTER TABLE `course` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `courseenrolls`
--

DROP TABLE IF EXISTS `courseenrolls`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `courseenrolls` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentRegno` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `session` int(11) DEFAULT NULL,
  `department` int(11) DEFAULT NULL,
  `level` int(11) DEFAULT NULL,
  `semester` int(11) DEFAULT NULL,
  `course` int(11) DEFAULT NULL,
  `enrollDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `courseenrolls`
--

LOCK TABLES `courseenrolls` WRITE;
/*!40000 ALTER TABLE `courseenrolls` DISABLE KEYS */;
INSERT INTO `courseenrolls` VALUES (4,'10806121','715948',4,7,6,5,2,'2018-05-21 10:19:41'),(5,'12345','131863',4,7,6,6,1,'2018-08-25 05:52:34'),(6,'st101','208458',4,7,6,5,1,'2020-07-30 13:18:11'),(7,'st101','208458',4,8,6,5,4,'2020-07-31 19:11:27'),(8,'st101','208458',4,10,7,5,5,'2020-07-31 19:20:31');
/*!40000 ALTER TABLE `courseenrolls` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` VALUES (3,'Admin','2017-02-09 18:52:08'),(7,'IT','2018-05-21 10:03:15'),(8,'Computer Science ','2020-07-30 15:04:22'),(9,'MBA','2020-07-30 15:06:13'),(10,'Commerce ','2020-07-30 15:06:32'),(11,'Tamil','2020-07-30 15:06:41');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `level`
--

DROP TABLE IF EXISTS `level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `level` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `level` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `level`
--

LOCK TABLES `level` WRITE;
/*!40000 ALTER TABLE `level` DISABLE KEYS */;
INSERT INTO `level` VALUES (5,'Level 1','2017-02-09 19:04:04'),(6,'level 2','2017-02-09 19:04:12'),(7,'level 4','2017-02-09 19:04:17');
/*!40000 ALTER TABLE `level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `semester`
--

DROP TABLE IF EXISTS `semester`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `semester` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `semester` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `semester`
--

LOCK TABLES `semester` WRITE;
/*!40000 ALTER TABLE `semester` DISABLE KEYS */;
INSERT INTO `semester` VALUES (4,'Second sem','2017-02-09 18:47:59',''),(5,'Third Sem','2017-02-09 18:48:04',''),(6,'Fourth Sem','2018-05-21 10:02:56','');
/*!40000 ALTER TABLE `semester` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `session` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `session` varchar(255) DEFAULT NULL,
  `creationDate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES (1,'2015','2017-02-09 18:16:51'),(2,'2016','2017-02-09 18:27:41'),(3,'2017','2018-05-21 10:01:54'),(4,'2018','2018-05-21 10:01:58');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `StudentRegno` varchar(255) NOT NULL,
  `studentPhoto` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `studentName` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `session` varchar(255) DEFAULT NULL,
  `department` varchar(255) DEFAULT NULL,
  `semester` varchar(255) DEFAULT NULL,
  `cgpa` decimal(10,2) DEFAULT NULL,
  `creationdate` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `updationDate` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`StudentRegno`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES ('10806121','logo.jpg','f925916e2754e5e03f75dd58a5733251','Anuj Kumar','715948','','','',7.25,'2017-02-11 19:38:32','21-05-2018 03:20:40 PM'),('12345',NULL,'f925916e2754e5e03f75dd58a5733251','John','131863','','','',0.00,'2018-08-25 05:50:51',''),('125966','','f925916e2754e5e03f75dd58a5733251','Test user','385864','','','',0.00,'2017-02-11 19:48:03',''),('st101',NULL,'32250170a0dca92d53ec9624f336ca24','vinoth','208458',NULL,NULL,NULL,NULL,'2020-07-30 13:15:54',NULL);
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userlog`
--

DROP TABLE IF EXISTS `userlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `userlog` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `studentRegno` varchar(255) DEFAULT NULL,
  `userip` binary(16) DEFAULT NULL,
  `loginTime` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `logout` varchar(255) DEFAULT NULL,
  `status` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userlog`
--

LOCK TABLES `userlog` WRITE;
/*!40000 ALTER TABLE `userlog` DISABLE KEYS */;
INSERT INTO `userlog` VALUES (1,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-11 20:05:58','',1),(2,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-11 20:07:18','',1),(3,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-11 20:08:46','',1),(4,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-11 20:26:15','',1),(5,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-11 20:27:11','',1),(6,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-11 20:28:19','',1),(7,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-11 20:29:30','',1),(8,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-11 20:30:39','12-02-2017 02:00:40 AM',1),(9,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-11 20:32:12','12-02-2017 02:21:40 AM',1),(10,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-11 20:51:50','12-02-2017 05:14:45 AM',1),(11,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-12 05:41:24','12-02-2017 11:49:58 AM',1),(12,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-12 06:20:05','',1),(13,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2017-02-12 06:20:23','12-02-2017 12:09:59 PM',1),(14,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2018-05-21 09:49:06','21-05-2018 03:30:53 PM',1),(15,'10806121',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2018-05-21 10:19:15','',1),(16,'12345',_binary '::1\0\0\0\0\0\0\0\0\0\0\0\0\0','2018-08-25 05:51:42','25-08-2018 11:23:02 AM',1),(17,'st101',_binary '42.110.181.141\0\0','2020-07-30 13:16:44','30-07-2020 06:48:35 PM',1),(18,'st101',_binary '42.111.152.177\0\0','2020-07-31 19:06:52','01-08-2020 12:36:58 AM',1),(19,'st101',_binary '42.111.152.177\0\0','2020-07-31 19:07:26','01-08-2020 12:42:06 AM',1),(20,'st101',_binary '42.111.160.163\0\0','2020-07-31 19:15:58','01-08-2020 12:46:44 AM',1),(21,'st101',_binary '42.111.160.163\0\0','2020-07-31 19:18:52','01-08-2020 12:50:51 AM',1);
/*!40000 ALTER TABLE `userlog` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2020-08-01  8:07:17
