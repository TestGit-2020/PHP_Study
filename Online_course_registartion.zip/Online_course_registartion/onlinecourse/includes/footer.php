<footer>
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    &copy; 2020 Online Course Registration | By : <a href="https://github.com/vinHome-2020/PHP_Study" target="_blank">VinHome</a>
                </div>

            </div>
        </div>
    </footer>